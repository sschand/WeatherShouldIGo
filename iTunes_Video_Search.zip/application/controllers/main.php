<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	public function index()
	{
		$this->load->view('test');
	}	

	public function test()
	{
	    $this->load->library('PHPRequests');
	    $response = Requests::get('https://github.com/timeline.json');
	    var_dump($response->body);
	}

	public function get_movie()
	{
	    $this->load->library('PHPRequests');

	    $artist = $this->input->post('user_input');
		$url = "https://itunes.apple.com/search?term=".$artist."&entity=musicVideo"; 
	    $response = Requests::post($url);
	    echo $response->body;
	}
}

//end of main controller